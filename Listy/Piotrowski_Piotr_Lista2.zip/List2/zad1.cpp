#include <Arduino.h>

#define LED_RED 6
#define LED_GREEN 5
#define LED_BLUE 3

#define RED_BUTTON 2
#define GREEN_BUTTON 4

#define DEBOUNCE_PERIOD 10UL

const int colors[] = {LED_RED, LED_GREEN, LED_BLUE};
const int colorCount = sizeof(colors) / sizeof(colors[0]);

int currentColor = 0;
bool ledOn = true;

bool lastRedPressed = false;
bool lastGreenPressed = false;

struct DebouncedButton {
    int pin;
    int debouncedState;
    int previousReading;
    unsigned long lastChangeTime;
};

DebouncedButton redButton = {RED_BUTTON, HIGH, HIGH, 0UL};
DebouncedButton greenButton = {GREEN_BUTTON, HIGH, HIGH, 0UL};

bool isReleased(DebouncedButton &button) {
    bool isReleased = false;
    int currentReading = digitalRead(button.pin);

    if (button.previousReading != currentReading) {
        button.lastChangeTime = millis();
    }

    if (millis() - button.lastChangeTime > DEBOUNCE_PERIOD) {
        if (currentReading != button.debouncedState) {
            if (button.debouncedState == LOW && currentReading == HIGH) {
                isReleased = true;
            }
            button.debouncedState = currentReading;
        }
    }

    button.previousReading = currentReading;

    return isReleased;
}

void updateLeds() {
    for (int i = 0; i < colorCount; i++) {
        digitalWrite(colors[i], (ledOn && i == currentColor) ? HIGH : LOW);
    }
}

void setup() {
    pinMode(LED_RED, OUTPUT);
    pinMode(LED_GREEN, OUTPUT);
    pinMode(LED_BLUE, OUTPUT);

    pinMode(RED_BUTTON, INPUT_PULLUP);
    pinMode(GREEN_BUTTON, INPUT_PULLUP);

    updateLeds();
}

void loop() {
    bool redReleased = isReleased(redButton);
    bool greenReleased = isReleased(greenButton);

    if (greenReleased) {
        currentColor = (currentColor + 1) % colorCount;
        updateLeds();
    }

    if (redReleased) {
        ledOn = !ledOn;
        updateLeds();
    }
}
